# Paweł Polerowicz 254626

println(floatmin(Float32))
println(floatmin(Float64))
